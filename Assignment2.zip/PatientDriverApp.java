/*
 * Class: CMSC203 
 * Instructor: Ashique Tanveer
 * Description: (The "PatientDriverApp" class functions as a driver program to 
 demonstrate the functionality of the "Patient" and "Procedure" classes. It 
 contains methods for displaying patient information and medical procedure details, 
 as well as for calculating total charges for procedures. The main method initializes 
 sample patient and procedure objects, displays their information, calculates total 
 charges, and prints identifying information such as the student's name, student ID, 
 and due date.)
 * Due: 02/27/2024
 * Platform/compiler: VSCode
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Raushan O.
*/


public class PatientDriverApp {
    public static void displayPatient(Patient patient) {
        System.out.println(patient);
    }

    public static void displayProcedure(Procedure procedure) {
        System.out.println(procedure);
    }

    public static double calculateTotalCharges(Procedure procedure1, Procedure procedure2, Procedure procedure3) {
        return procedure1.getCharges() + procedure2.getCharges() + procedure3.getCharges();
    }

    public static void main(String[] args) {
        // Creating a Patient instance with sample data
        Patient patient = new Patient("Jenny", "Elaine", "Santori",
                "123 Main Street", "MyTown", "CA", "01234",
                "902-107-1738", "Bill Santori", "443-745-0702");

        // Creating three Procedure instances with sample data
        Procedure procedure1 = new Procedure("Physical Exam", "01/29/2024", "Dr. Irvine", 3250.0);
        Procedure procedure2 = new Procedure("X-Ray", "03/07/2024", "Dr. Jamison", 5500.43);
        Procedure procedure3 = new Procedure("Blood Test", "4/20/2024", "Dr. Smith", 1400.75);

        
        displayPatient(patient);
        displayProcedure(procedure1);
        displayProcedure(procedure2);
        displayProcedure(procedure3);

        // Calculating+Display charges
        double totalCharges = calculateTotalCharges(procedure1, procedure2, procedure3);
        System.out.println("\nTotal Charges are: " + totalCharges + "\n");
        System.out.println("Student Name: Raushan Oshan");
        System.out.println("M21159112");
        System.out.println("Due Date: 02/27/24");
    }
}
