/*
 * Class: CMSC203 
 * Instructor: Ashique Tanveer
 * Description: (The "Procedure" class manages information about medical procedures, including 
 the procedure's name, date, practitioner, and charges. It offers constructors for initializing 
 objects with varying levels of detail and provides setter methods to modify the information. 
 Getter methods allow retrieving the procedure details. The toString method is overridden to 
 generate a formatted string representation of the procedure object, including its name, date, 
 practitioner, and charges.)
 * Due: 02/27/2024
 * Platform/compiler: VSCode
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Raushan O.
*/

public class Procedure {
    private String procedureName;
    private String procedureDate;
    private String procedurePractitioner;
    private double charges;

    public Procedure() {
    }

    public Procedure(String procedureName, String procedureDate) {
        this.procedureName = procedureName;
        this.procedureDate = procedureDate;
    }

    public Procedure(String procedureName, String procedureDate, String procedurePractitioner, double charges) {
        this.procedureName = procedureName;
        this.procedureDate = procedureDate;
        this.procedurePractitioner = procedurePractitioner;
        this.charges = charges;
    }

    public void setProcedureName(String procedureName) {
        this.procedureName = procedureName;
    }

    public void setProcedureDate(String procedureDate) {
        this.procedureDate = procedureDate;
    }

    public void setProcedurePractitioner(String procedurePractitioner) {
        this.procedurePractitioner = procedurePractitioner;
    }

    public void setCharges(double charges) {
        this.charges = charges;
    }
    
    public String getProcedureName() {
        return procedureName;
    }

    public String getProcedureDate() {
        return procedureDate;
    }

    public String getProcedurePractitioner() {
        return procedurePractitioner;
    }

    public double getCharges() {
        return charges;
    }

    public String toString() {
        return "\nProcedure: " + procedureName + "\n" +
                "Procedure Date: " + procedureDate + "\n" +
                "Practitioner: " + procedurePractitioner + "\n" +
                "Charges: $" + charges;
    }
}