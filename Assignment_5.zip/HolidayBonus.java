/*
 * Class: CMSC203 
 * Instructor: Professor Tanveer
 * Description: (This class, "HolidayBonus," encapsulates methods to calculate holiday bonuses based
on sales data stored in a two-dimensional array. The method "calculateHolidayBonus" computes 
individual bonuses for each store based on their sales performance, while "calculateTotalHolidayBonus" 
calculates the total bonus for all stores combined. It utilizes a predefined set of constants for
bonus values and leverages methods from the "TwoDimRaggedArrayUtility" class to determine sales 
metrics such as highest, lowest, and total sales.)
 * Due: 04/16/2024
 * Platform/compiler:vsCode
 * I pledge that I have completed the programming assignment independently.
*  I have not copied the code from a student or any source. 
*  I have not given my code to any student.
*  Print your Name here: Raushan O. 
*/

public class HolidayBonus {

    private static final double HIGHEST_BONUS = 5000.0;
    private static final double LOWEST_BONUS = 1000.0;
    private static final double OTHER_BONUS = 2000.0;

    public static double[] calculateHolidayBonus(double[][] data) {
        double[] bonuses = new double[data.length];
        
        for (int i = 0; i < data.length; i++) {
            double highestSales = TwoDimRaggedArrayUtility.getHighestInRow(data, i);
            double lowestSales = TwoDimRaggedArrayUtility.getLowestInRow(data, i);
            double totalSales = TwoDimRaggedArrayUtility.getRowTotal(data, i);
            
            if (highestSales == lowestSales) {
                bonuses[i] = HIGHEST_BONUS;
            } else {
                bonuses[i] = (totalSales - highestSales - lowestSales) * OTHER_BONUS + HIGHEST_BONUS + LOWEST_BONUS;
            }
        }
        
        return bonuses;
    }

    public static double calculateTotalHolidayBonus(double[][] data) {
        double totalBonus = 0.0;
        
        for (double[] storeSales : data) {
            double highestSales = TwoDimRaggedArrayUtility.getHighestInArray(data);
            double lowestSales = TwoDimRaggedArrayUtility.getLowestInArray(data);
            double totalSales = TwoDimRaggedArrayUtility.getTotal(data);
            
            if (highestSales == lowestSales) {
                totalBonus += HIGHEST_BONUS;
            } else {
                totalBonus += (totalSales - highestSales - lowestSales) * OTHER_BONUS + HIGHEST_BONUS + LOWEST_BONUS;
            }
        }
        
        return totalBonus;
    }
}
