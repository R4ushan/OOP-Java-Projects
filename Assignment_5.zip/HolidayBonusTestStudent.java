/*
 * Class: CMSC203 
 * Instructor: Professor Tanveer
 * Description: (This is a JUnit test class named "HolidayBonusTestStudent" 
which tests the functionality of methods in a class called "HolidayBonus". It contains test methods
such as "testCalculateHolidayBonus" and "testCalculateTotalHolidayBonus" which verify the 
correctness of holiday bonus calculations based on different data sets. The tests use assertions to
ensure that the expected results match the actual results with a certain precision.)
 * Due: 04/16/2024
 * Platform/compiler:vsCode
 * I pledge that I have completed the programming assignment independently.
*  I have not copied the code from a student or any source. 
*  I have not given my code to any student.
*  Print your Name here: Raushan O. 
*/
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class HolidayBonusTestStudent {

    private double[][] dataSet1 = { { 1000, 2000, 3000 }, { 4000, 5000 }, { 6000, 7000, 8000 } };
    private double[][] dataSet2 = { { 2000, 3000, 4000 }, { 5000, 6000 }, { 7000, 8000, 9000 } };

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void testCalculateHolidayBonus() {
        try {
            double[] result1 = HolidayBonus.calculateHolidayBonus(dataSet1);
            assertEquals(4006000.0, result1[0], .001);
            assertEquals(6000.0, result1[1], .001);
            assertEquals(1.4006E7, result1[2], .001);

            double[] result2 = HolidayBonus.calculateHolidayBonus(dataSet2);
            assertEquals(6006000.0, result2[0], .001);
            assertEquals(6000.0, result2[1], .001);
            assertEquals(1.6006E7, result2[2], .001);
        } catch (Exception e) {
            fail("This should not have caused an Exception");
        }
    }

    @Test
    public void testCalculateTotalHolidayBonus() {
        assertEquals(1.62018E8, HolidayBonus.calculateTotalHolidayBonus(dataSet1), .001);
        assertEquals(1.98018E8, HolidayBonus.calculateTotalHolidayBonus(dataSet2), .001);
    }
}

