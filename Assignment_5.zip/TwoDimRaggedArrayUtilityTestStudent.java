/*
 * Class: CMSC203 
 * Instructor: Professor Tanveer
 * Description: (This JUnit test class, "TwoDimRaggedArrayUtilityTestStudent," comprehensively tests
 the functionalities of the "TwoDimRaggedArrayUtility" class. It includes tests for methods such 
 as reading and writing data from/to files, calculating total and average values, computing row and
column totals, finding highest and lowest values in rows and columns, and identifying the highest 
and lowest values in the entire array. Each test method verifies the expected behavior of its corresponding utility 
method by comparing actual results against expected results using assertion statements. Additionally, the setup and teardown 
methods ensure proper initialization and cleanup of temporary files used for testing.
)
 * Due: 04/16/2024
 * Platform/compiler:vsCode
 * I pledge that I have completed the programming assignment independently.
*  I have not copied the code from a student or any source. 
*  I have not given my code to any student.
*  Print your Name here: Raushan O. 
*/
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import java.io.File;
import java.io.FileNotFoundException;

public class TwoDimRaggedArrayUtilityTestStudent {
    private double[][] dataSet1 = {{1, 2, 3}, {4, 5}, {6, 7, 8, 9}};
    private File file1;
    private File file2;

    @Before
    public void setUp() {
        try {
            file1 = File.createTempFile("test1", ".txt");
            file2 = File.createTempFile("test2", ".txt");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @After
    public void tearDown() {
        file1.delete();
        file2.delete();
    }

    @Test
    public void testReadFile() {
        try {
            TwoDimRaggedArrayUtility.writeToFile(dataSet1, file1);
            double[][] result = TwoDimRaggedArrayUtility.readFile(file1);
            assertArrayEquals(dataSet1, result);
        } catch (FileNotFoundException e) {
            fail("File not found exception occurred.");
        }
    }

    @Test
    public void testWriteToFile() {
        try {
            TwoDimRaggedArrayUtility.writeToFile(dataSet1, file1);
            double[][] result = TwoDimRaggedArrayUtility.readFile(file1);
            assertArrayEquals(dataSet1, result);
        } catch (FileNotFoundException e) {
            fail("File not found exception occurred.");
        }
    }

    @Test
    public void testGetTotal() {
        assertEquals(45.0, TwoDimRaggedArrayUtility.getTotal(dataSet1), .001);
    }

    @Test
    public void testGetAverage() {
        assertEquals(5.0, TwoDimRaggedArrayUtility.getAverage(dataSet1), .001);
    }

    @Test
    public void testGetRowTotal() {
        assertEquals(9.0, TwoDimRaggedArrayUtility.getRowTotal(dataSet1, 1), .001);
    }

    @Test
    public void testGetColumnTotal() {
        assertEquals(11.0, TwoDimRaggedArrayUtility.getColumnTotal(dataSet1, 0), .001);
    }

    @Test
    public void testGetHighestInRow() {
        assertEquals(9.0, TwoDimRaggedArrayUtility.getHighestInRow(dataSet1, 2), .001);
    }

    @Test
    public void testGetHighestInRowIndex() {
        assertEquals(3, TwoDimRaggedArrayUtility.getHighestInRowIndex(dataSet1, 2));
    }

    @Test
    public void testGetLowestInRow() {
        assertEquals(4.0, TwoDimRaggedArrayUtility.getLowestInRow(dataSet1, 1), .001);
    }

    @Test
    public void testGetLowestInRowIndex() {
        assertEquals(0, TwoDimRaggedArrayUtility.getLowestInRowIndex(dataSet1, 0));
    }

    @Test
    public void testGetHighestInColumn() {
        assertEquals(6.0, TwoDimRaggedArrayUtility.getHighestInColumn(dataSet1, 0), .001);
    }

    @Test
    public void testGetHighestInColumnIndex() {
        assertEquals(2, TwoDimRaggedArrayUtility.getHighestInColumnIndex(dataSet1, 0));
    }

    @Test
    public void testGetLowestInColumn() {
        assertEquals(1.0, TwoDimRaggedArrayUtility.getLowestInColumn(dataSet1, 0), .001);
    }

    @Test
    public void testGetLowestInColumnIndex() {
        assertEquals(0, TwoDimRaggedArrayUtility.getLowestInColumnIndex(dataSet1, 0));
    }

    @Test
    public void testGetHighestInArray() {
        assertEquals(9.0, TwoDimRaggedArrayUtility.getHighestInArray(dataSet1), .001);
    }

    @Test
    public void testGetLowestInArray() {
        assertEquals(1.0, TwoDimRaggedArrayUtility.getLowestInArray(dataSet1), .001);
    }
}