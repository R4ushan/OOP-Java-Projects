public class DataManager {

    DataManager() {}

    public String getHello() {
        return "Hello World";
    }

    public String getHowdy() {
        return "Howdy y'all";
    }

    public String getChinese() {
        return "Ni hao";
    }
}
