import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class CoffeeTestStudent {

    @Test
    public void testCalcPrice_NoExtras() {
        Coffee coffee = new Coffee("Latte", Size.SMALL, false, false);
        double expectedPrice = 2.0; // Small size price without extras
        assertEquals(expectedPrice, coffee.calcPrice(), 0.001);
    }

    @Test
    public void testCalcPrice_ExtraShot() {
        Coffee coffee = new Coffee("Cappuccino", Size.MEDIUM, true, false);
        double expectedPrice = 3.0; // Medium size price with extra shot
        assertEquals(expectedPrice, coffee.calcPrice(), 0.001);
    }

    @Test
    public void testCalcPrice_ExtraSyrup() {
        Coffee coffee = new Coffee("Mocha", Size.LARGE, false, true);
        double expectedPrice = 3.0; // Large size price with extra syrup
        assertEquals(expectedPrice, coffee.calcPrice(), 0.001);
    }

    @Test
    public void testCalcPrice_BothExtras() {
        Coffee coffee = new Coffee("Americano", Size.SMALL, true, true);
        double expectedPrice = 3.0; // Small size price with both extras
        assertEquals(expectedPrice, coffee.calcPrice(), 0.001);
    }

    @Test
    public void testToString() {
        Coffee coffee = new Coffee("Espresso", Size.MEDIUM, true, false);
        String expectedString = "Coffee [bevName=Espresso, size=MEDIUM, extraShot=true, extraSyrup=false]";
        assertEquals(expectedString, coffee.toString());
    }
}

