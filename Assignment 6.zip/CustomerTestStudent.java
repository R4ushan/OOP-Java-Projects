import static org.junit.Assert.*;
import org.junit.Test;

public class CustomerTestStudent {

    @Test
    public void testCustomerConstructor() {
        Customer customer = new Customer("John", 30);
        assertEquals("John", customer.getName());
        assertEquals(30, customer.getAge());
    }

    @Test
    public void testCustomerCopyConstructor() {
        Customer originalCustomer = new Customer("Alice", 25);
        Customer copiedCustomer = new Customer(originalCustomer);
        assertEquals(originalCustomer.getName(), copiedCustomer.getName());
        assertEquals(originalCustomer.getAge(), copiedCustomer.getAge());
    }

    @Test
    public void testSetName() {
        Customer customer = new Customer("Bob", 40);
        customer.setName("Charlie");
        assertEquals("Charlie", customer.getName());
    }

    @Test
    public void testSetAge() {
        Customer customer = new Customer("Eve", 35);
        customer.setAge(45);
        assertEquals(45, customer.getAge());
    }

    @Test
    public void testToString() {
        Customer customer = new Customer("Frank", 50);
        String expectedString = "Customer{name='Frank', age=50}";
        assertEquals(expectedString, customer.toString());
    }
}

