import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class OrderTestStudent {

    private Order order;
    private Customer customer;

    @Before
    public void setUp() {
        customer = new Customer("John Doe", 30);
        order = new Order(12, Day.MONDAY, customer);
    }

    @Test
    public void testIsWeekend_WeekendDay() {
        order = new Order(12, Day.SATURDAY, customer);
        assertTrue(order.isWeekend());
    }

    @Test
    public void testIsWeekend_Weekday() {
        order = new Order(12, Day.MONDAY, customer);
        assertFalse(order.isWeekend());
    }

    @Test
    public void testGetBeverage() {
        order.addNewBeverage("Latte", Size.SMALL, true, false);
        assertEquals("Latte", order.getBeverage(0).getBevName());
    }

    @Test
    public void testCalcOrderTotal() {
        order.addNewBeverage("Latte", Size.SMALL, true, false);
        order.addNewBeverage("Beer", Size.MEDIUM);
        order.addNewBeverage("Tropical", Size.LARGE, 2, true);
        double expectedTotal = 2.5 + 3.0 + 4.5; // Latte + Beer + Smoothie
        assertEquals(expectedTotal, order.calcOrderTotal(), 0.001);
    }

    @Test
    public void testFindNumOfBeveType() {
        order.addNewBeverage("Latte", Size.SMALL, true, false);
        order.addNewBeverage("Beer", Size.MEDIUM);
        order.addNewBeverage("Tropical", Size.LARGE, 2, true);
        assertEquals(1, order.findNumOfBeveType(Type.COFFEE));
        assertEquals(1, order.findNumOfBeveType(Type.ALCOHOL));
        assertEquals(1, order.findNumOfBeveType(Type.SMOOTHIE));
    }

    @Test
    public void testToString() {
        order.addNewBeverage("Latte", Size.SMALL, true, false);
        order.addNewBeverage("Beer", Size.MEDIUM);
        String expectedString = "Order Number: " + order.getOrderNumber() + "\n" +
                                "Order Time: 12\n" +
                                "Order Day: MONDAY\n" +
                                "Customer: Customer{name='John Doe', age=30}\n" +
                                "Beverages:\n" +
                                "Coffee [bevName=Latte, size=SMALL, extraShot=true, extraSyrup=false]\n" +
                                "Alcohol [bevName=Beer, size=MEDIUM, weekendOffer=false]\n";
        assertEquals(expectedString, order.toString());
    }

    @Test
    public void testGetTotalItems() {
        order.addNewBeverage("Latte", Size.SMALL, true, false);
        order.addNewBeverage("Beer", Size.MEDIUM);
        order.addNewBeverage("Tropical", Size.LARGE, 2, true);
        assertEquals(36, order.getTotalItems()); // 8 + 8 ounces
    }
}
