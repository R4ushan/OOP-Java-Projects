public enum Day {
    MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY;

    boolean isWeekday() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'isWeekday'");
    }

    boolean isWeekend() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'isWeekend'");
    }

    Object nextDay() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'nextDay'");
    }

    Object previousDay() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'previousDay'");
    }
}
