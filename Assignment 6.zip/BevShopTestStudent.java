import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class BevShopTestStudent {

    private BevShop bevShop;

    @Before
    public void setUp() {
        bevShop = new BevShop();
    }

    @Test
    public void testIsValidTime_ValidTime() {
        assertTrue(bevShop.isValidTime(12)); // 12 PM is within valid time
    }

    @Test
    public void testIsValidTime_InvalidTime() {
        assertFalse(bevShop.isValidTime(6)); // 6 AM is outside valid time
    }

    @Test
    public void testIsMaxFruit_ExceedMaxFruit() {
        assertTrue(bevShop.isMaxFruit(6)); // 6 fruits exceed maximum allowed
    }

    @Test
    public void testIsMaxFruit_NotExceedMaxFruit() {
        assertFalse(bevShop.isMaxFruit(3)); // 3 fruits are within the maximum allowed
    }

    @Test
    public void testIsEligibleForMore() {
        assertTrue(bevShop.isEligibleForMore()); // When no alcohol drinks ordered yet
    }

    @Test
    public void testIsNotEligibleForMore() {
        for (int i = 0; i < BevShop.MAX_ORDER_FOR_ALCOHOL; i++) {
            bevShop.processAlcoholOrder("Wine", Size.MEDIUM);
        }
    }

    @Test
    public void testIsValidAge_ValidAge() {
        assertTrue(bevShop.isValidAge(21)); // 21 years is valid age for alcohol
    }

    @Test
    public void testIsValidAge_InvalidAge() {
        assertFalse(bevShop.isValidAge(18)); // 18 years is below valid age for alcohol
    }

    @Test
    public void testStartNewOrder_ValidTime() {
        bevShop.startNewOrder(15, Day.MONDAY, "John", 25); // valid time
        assertEquals(1, bevShop.totalNumOfMonthlyOrders()); // New order added
    }

    @Test
    public void testStartNewOrder_InvalidTime() {
        bevShop.startNewOrder(6, Day.MONDAY, "John", 25); // invalid time
        assertEquals(0, bevShop.totalNumOfMonthlyOrders()); // No order added
    }

    @Test
    public void testProcessCoffeeOrder() {
        bevShop.startNewOrder(15, Day.MONDAY, "John", 25);
        bevShop.processCoffeeOrder("Latte", Size.SMALL, true, false);
        assertEquals(8, bevShop.getTotalItems()); // 1 coffee order added
    }

    @Test
    public void testProcessAlcoholOrder() {
        bevShop.startNewOrder(15, Day.MONDAY, "John", 25);
        bevShop.processAlcoholOrder("Beer", Size.MEDIUM);
        assertEquals(12, bevShop.getTotalItems()); // 1 alcohol order added
    }

    @Test
    public void testProcessSmoothieOrder() {
        bevShop.startNewOrder(15, Day.MONDAY, "John", 25);
        bevShop.processSmoothieOrder("Tropical", Size.LARGE, 2, true);
        assertEquals(16, bevShop.getTotalItems()); // 1 smoothie order added
    }

    @Test
    public void testFindOrder_ExistingOrder() {
        bevShop.startNewOrder(15, Day.MONDAY, "John", 25);
        int orderNo = bevShop.getCurrentOrder().getOrderNumber();
        assertEquals(0, bevShop.findOrder(orderNo)); // Existing order found
    }

    @Test
    public void testFindOrder_NonExistingOrder() {
        assertEquals(-1, bevShop.findOrder(123)); // Non-existing order
    }

    @Test
    public void testTotalOrderPrice_ExistingOrder() {
        bevShop.startNewOrder(15, Day.MONDAY, "John", 25);
        bevShop.processCoffeeOrder("Latte", Size.SMALL, true, false);
        double expectedPrice = 2.5; // Price of small latte
        assertEquals(expectedPrice, bevShop.totalOrderPrice(bevShop.getCurrentOrder().getOrderNumber()), 0.001);
    }

    @Test
    public void testTotalMonthlySale() {
        bevShop.startNewOrder(15, Day.MONDAY, "John", 25);
        bevShop.processCoffeeOrder("Latte", Size.SMALL, true, false);
        bevShop.startNewOrder(16, Day.TUESDAY, "Alice", 30);
        bevShop.processAlcoholOrder("Beer", Size.MEDIUM);
        double expectedSale = 2.0 + 3.0; // Price of small latte + price of medium beer
        assertEquals(expectedSale, bevShop.totalMonthlySale(), 0.001);
    }

    @Test
    public void testSortOrders() {
        bevShop.startNewOrder(15, Day.MONDAY, "John", 25);
        bevShop.startNewOrder(16, Day.TUESDAY, "Alice", 30);
        bevShop.sortOrders();
    }
}

