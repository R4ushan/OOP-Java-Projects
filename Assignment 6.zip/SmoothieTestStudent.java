import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class SmoothieTestStudent {

    @Test
    public void testCalcPrice_NoFruits_NoProtein() {
        Smoothie smoothie = new Smoothie("Tropical", Size.SMALL, 0, false);
        double expectedPrice = 2.0; // Small size price without fruits or protein
        assertEquals(expectedPrice, smoothie.calcPrice(), 0.001);
    }

    @Test
    public void testCalcPrice_WithFruits_NoProtein() {
        Smoothie smoothie = new Smoothie("Berry Blast", Size.MEDIUM, 3, false);
        double expectedPrice = 4.0; // Medium size price with 3 fruits and no protein
        assertEquals(expectedPrice, smoothie.calcPrice(), 0.001);
    }

    @Test
    public void testCalcPrice_NoFruits_WithProtein() {
        Smoothie smoothie = new Smoothie("Green Machine", Size.LARGE, 0, true);
        double expectedPrice = 4.0; // Large size price without fruits and with protein
        assertEquals(expectedPrice, smoothie.calcPrice(), 0.001);
    }

    @Test
    public void testCalcPrice_WithFruits_AndProtein() {
        Smoothie smoothie = new Smoothie("Protein Power", Size.SMALL, 2, true);
        double expectedPrice = 4.5; // Small size price with 2 fruits and with protein
        assertEquals(expectedPrice, smoothie.calcPrice(), 0.001);
    }

    @Test
    public void testToString() {
        Smoothie smoothie = new Smoothie("Mango Madness", Size.MEDIUM, 1, false);
        String expectedString = "Smoothie [bevName=Mango Madness, size=MEDIUM, numFruits=1, proteinPowder=false]";
        assertEquals(expectedString, smoothie.toString());
    }
}

