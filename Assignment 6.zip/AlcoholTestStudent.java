import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class AlcoholTestStudent {

    @Test
    public void testCalcPrice_WeekendOffer() {
        Alcohol alcohol = new Alcohol("Wine", Size.MEDIUM, true);
        double expectedPrice = 3.0 + 0.1; // Medium size price + weekend offer cost
        assertEquals(expectedPrice, alcohol.calcPrice(), 0.001);
    }

    @Test
    public void testCalcPrice_NoWeekendOffer() {
        Alcohol alcohol = new Alcohol("Beer", Size.SMALL, false);
        double expectedPrice = 2.0; // Small size price without weekend offer
        assertEquals(expectedPrice, alcohol.calcPrice(), 0.001);
    }

    @Test
    public void testToString() {
        Alcohol alcohol = new Alcohol("Whiskey", Size.LARGE, true);
        String expectedString = "Alcohol [bevName=Whiskey, size=LARGE, weekendOffer=true]";
        assertEquals(expectedString, alcohol.toString());
    }
}

