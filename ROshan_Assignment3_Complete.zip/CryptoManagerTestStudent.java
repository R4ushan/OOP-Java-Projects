import static org.junit.Assert.*;
import org.junit.Test;

public class CryptoManagerTestStudent {

    @Test
    public void testCaesarEncryption() {
        assertEquals("Encrypting 'HELLO' with key 3", "KHOOR", CryptoManager.caesarEncryption("HELLO", 3));
        assertEquals("Encrypting 'WORLD' with key 4", "[SVPH", CryptoManager.caesarEncryption("WORLD", 4));
    }

    @Test
    public void testCaesarDecryption() {
        assertEquals("Decrypting 'KHOOR' with key 3", "HELLO", CryptoManager.caesarDecryption("KHOOR", 3));
        assertEquals("Decrypting 'BKTWP' with key 5", "=FORK", CryptoManager.caesarDecryption("BKTWP", 5));
    }

    @Test
    public void testBellasoEncryption() {
        assertEquals("Encrypting 'HELLO' with Bellaso 'ABC'", "IGOMQ", CryptoManager.bellasoEncryption("HELLO", "ABC"));
        assertEquals("Encrypting 'HAPPY' with Bellaso 'XYZ'", " Z*(2", CryptoManager.bellasoEncryption("HAPPY", "XYZ"));
    }

    @Test
    public void testBellasoDecryption() {
        assertEquals("Decrypting 'HFNOS' with Bellaso 'ABC'", "GDKNQ", CryptoManager.bellasoDecryption("HFNOS", "ABC"));
        assertEquals("Decrypting 'YWGXB' with Bellaso 'XYZ'", "A>-@)", CryptoManager.bellasoDecryption("YWGXB", "XYZ"));
    }

    @Test
    public void testIsStringInBoundsValid() {
        assertTrue("String within bounds", CryptoManager.isStringInBounds("HELLO"));
    }
}
    